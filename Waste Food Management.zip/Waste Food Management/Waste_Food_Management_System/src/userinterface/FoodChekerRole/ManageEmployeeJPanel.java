/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package userinterface.FoodChekerRole;

import userinterface.AdministrativeRole.*;
import Business.Driver.Driver;
import Business.Employee.Employee;
import static Business.Enterprise.Enterprise.EnterpriseType.Food_Source;
import Business.Helper.Helper;
import Business.Homeless.HomelessPeople;
import Business.Organization.Organization;
import Business.Organization.OrganizationDirectory;
import Business.Homeless.HomelessPeopleDirectory;
import Business.NormalUser.NormalPeople;
import Business.Organization.Organization.Type;
import Business.Restaurant.Restaurant;
import Business.Restaurant.RestaurantDirectory;
import java.awt.CardLayout;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Shubham
 */
public class ManageEmployeeJPanel extends javax.swing.JPanel {

    private OrganizationDirectory organizationDir;
    private RestaurantDirectory restaurantDirectory;
    private HomelessPeopleDirectory homelessPeopleDirectory;
    private JPanel userProcessContainer;
    private int i=1;
    
    /**
     * Creates new form ManageOrganizationJPanel
     */
    public ManageEmployeeJPanel(JPanel userProcessContainer,OrganizationDirectory organizationDir) {
        initComponents();
        this.userProcessContainer = userProcessContainer;
        this.organizationDir = organizationDir;
        this.homelessPeopleDirectory = homelessPeopleDirectory;
       
        populateOrganizationComboBox();
        populateOrganizationEmpComboBox();
    }
    
    public void populateOrganizationComboBox(){
        organizationJComboBox.removeAllItems();
        
        for (Organization organization : organizationDir.getOrganizationList()){
            organizationJComboBox.addItem(organization);
        }
    }
    
    public void populateOrganizationEmpComboBox(){
        organizationEmpJComboBox.removeAllItems();
        
        for (Organization organization : organizationDir.getOrganizationList()){
            organizationEmpJComboBox.addItem(organization);
        }
    }

    private void populateTable(Organization organization){
        DefaultTableModel model = (DefaultTableModel) organizationJTable.getModel();
        
        model.setRowCount(0);
        
        if(organization.getName().equalsIgnoreCase("RestaurantOrganization"))
        {
            if(organization.getRestaurantDirectory().getRestaurantDirectory().size() != 0){
            for (Restaurant restaurant : organization.getRestaurantDirectory().getRestaurantDirectory())
            {
                Object[] row= new Object[2];
                row[0]= restaurant.getId();
                row[1]= restaurant.getResName();
                model.addRow(row);
            }
            }
        }
        
        for (Employee employee : organization.getEmployeeDirectory().getEmployeeList()){
            Object[] row = new Object[2];
            
            if(organization.getName().equalsIgnoreCase("HomelessPeople Organization"))
            {
                row[0] = employee.homelessPeopleCount();
                
            }
            if(organization.getName().equalsIgnoreCase("NormalPeople Organization"))
            {
                row[0] = employee.normalPeopleCount();
            }
            if(organization.getName().equalsIgnoreCase("Driver Organization"))
            {
                row[0] = employee.driverCount();
                
            }
            if(organization.getName().equalsIgnoreCase("Helper Organization"))
            {
                row[0] = employee.helperCount();
            }
            row[1] = employee.getName();
            
            model.addRow(row);
        }
//        if(organization.getName().equalsIgnoreCase("Driver Organization"))
//        {
//        for (Driver driver : organization.getDriverDirectory().getDriverDirectory()){
//            Object[] row = new Object[2];
//            row[0] = driver.getId();
//            row[1] = driver.getName();
//            model.addRow(row);
//        }
//        if(organization.getName().equalsIgnoreCase("Helper Organization"))
//        {
//        for (Helper helper : organization.getHelperDirectory().getHelperDirectory()){
//            Object[] row = new Object[2];
//            row[0] = helper.getId();
//            row[1] = helper.getName();
//            model.addRow(row);  
//        }
//        if(organization.getName().equalsIgnoreCase("NormalPeople Organization"))
//        {
//        for (NormalPeople normalPeople : organization.getNormalPeoplwDirectory().getNormalPeopleDirecory())
//            {
//            Object[] row = new Object[2];
//            row[0] = normalPeople.getId();
//            row[1] = normalPeople.getName();
//            model.addRow(row);
//            }
//        }
//        if(organization.getName().equalsIgnoreCase("HomelessPeople Organization"))
//        {
//        for(HomelessPeople homelessPeople: organization.getHomelessPeopleDirectory().getHomeLessPeopleDirecory())
//        {
//            Object[] row = new Object[2];
//            row[0] = homelessPeople.getId();
//            row[1] = homelessPeople.getName();
//            model.addRow(row);
//            
//        }
//        }
//        
//        }
//        }
        
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        organizationJTable = new javax.swing.JTable();
        addJButton = new javax.swing.JButton();
        organizationJComboBox = new javax.swing.JComboBox();
        jLabel1 = new javax.swing.JLabel();
        backJButton = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        nameJTextField = new javax.swing.JTextField();
        organizationEmpJComboBox = new javax.swing.JComboBox();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        contactJTextField = new javax.swing.JTextField();
        addressJTextField = new javax.swing.JTextField();
        ssnJTextField = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();

        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        organizationJTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "ID", "Name"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(organizationJTable);
        if (organizationJTable.getColumnModel().getColumnCount() > 0) {
            organizationJTable.getColumnModel().getColumn(0).setResizable(false);
            organizationJTable.getColumnModel().getColumn(1).setResizable(false);
        }

        add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 40, 660, 92));

        addJButton.setText("Create User");
        addJButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addJButtonActionPerformed(evt);
            }
        });
        add(addJButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 500, -1, -1));

        organizationJComboBox.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        organizationJComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                organizationJComboBoxActionPerformed(evt);
            }
        });
        add(organizationJComboBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 40, 184, -1));

        jLabel1.setText("Organization");
        add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 40, -1, -1));

        backJButton.setText("<< Back");
        backJButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backJButtonActionPerformed(evt);
            }
        });
        add(backJButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 500, -1, -1));

        jLabel2.setText("Name");
        add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 300, -1, -1));

        nameJTextField.setEnabled(false);
        add(nameJTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 300, 187, -1));

        organizationEmpJComboBox.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        organizationEmpJComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                organizationEmpJComboBoxActionPerformed(evt);
            }
        });
        add(organizationEmpJComboBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 170, 187, -1));

        jLabel3.setText("Organization");
        add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 170, -1, -1));

        jLabel4.setText("Contact No.");
        add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 330, 89, -1));

        jLabel5.setText("SSN no.");
        add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 370, -1, -1));

        jLabel6.setText("Address");
        add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 410, -1, -1));

        contactJTextField.setEnabled(false);
        add(contactJTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 330, 187, -1));

        addressJTextField.setEnabled(false);
        add(addressJTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 410, 187, -1));

        ssnJTextField.setEnabled(false);
        add(ssnJTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 370, 187, -1));

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel13.setText("Add Users below");
        add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 230, 200, -1));
    }// </editor-fold>//GEN-END:initComponents

    private void addJButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addJButtonActionPerformed
        Organization organization = (Organization) organizationEmpJComboBox.getSelectedItem();
        //String name = nameJTextField.getText();
        
        Employee employee = organization.getEmployeeDirectory().createEmployee();
        employee.setAddress(addressJTextField.getText());
        employee.setName(nameJTextField.getText());
        employee.setContact(Integer.parseInt(contactJTextField.getText()));
        employee.setSsn(Integer.parseInt(ssnJTextField.getText()));
        JOptionPane.showMessageDialog(null, "User added successfully");
        addressJTextField.setText("");
        nameJTextField.setText("");
        contactJTextField.setText("");
        ssnJTextField.setText("");
        
//       if(organization.getName().equalsIgnoreCase("HomelessPeople Organization")) 
//       {
//            HomelessPeople homelessPeople= organization.getHomelessPeopleDirectory().addHomeLessPeople();
//            homelessPeople.setName(nameJTextField.getText());
//            homelessPeople.setContact(Integer.parseInt(contactJTextField.getText()));
//            homelessPeople.setAddress(addressJTextField.getText());
//            homelessPeople.setSSN(Integer.parseInt(ssnJTextField.getText()));
//            
//            //JOptionPane.showMessageDialog(null,"Added successfully");
//            nameJTextField.setText("");
//            addressJTextField.setText("");
//            contactJTextField.setText("");
//            ssnJTextField.setText("");
//            
//            JOptionPane.showMessageDialog(null,"Person added successfully");
//        }
//        if(organization.getName().equalsIgnoreCase("NormalPeople Organization"))
//        {
//            NormalPeople normalPeople = organization.getNormalPeoplwDirectory().addNormalPeople();
//            normalPeople.setName(nameJTextField.getText());
//            normalPeople.setAddress(addressJTextField.getText());
//            normalPeople.setContact(Integer.parseInt(contactJTextField.getText()));
//            normalPeople.setSSN(Integer.parseInt(ssnJTextField.getText()));
//            nameJTextField.setText("");
//            addressJTextField.setText("");
//            contactJTextField.setText("");
//            ssnJTextField.setText("");
//            JOptionPane.showMessageDialog(null,"Person added successfully");
//            
//        }
//        if(organization.getName().equals("Driver Organization"))
//        {
//            Driver driver = organization.getDriverDirectory().addDriver();
//            driver.setName(nameJTextField.getText());
//            driver.setAddress(addressJTextField.getText());
//            driver.setContact(Integer.parseInt(contactJTextField.getText()));
//            driver.setSSN(Integer.parseInt(ssnJTextField.getText()));
//            nameJTextField.setText("");
//            addressJTextField.setText("");
//            contactJTextField.setText("");
//            ssnJTextField.setText("");
//            JOptionPane.showMessageDialog(null,"Person added successfully");
//        
//        }
//        if(organization.getName().equalsIgnoreCase("Helper Organization"))
//        {
//            Helper helper = organization.getHelperDirectory().addHelper();
//            helper.setAddress(addressJTextField.getText());
//            helper.setContact(Integer.parseInt(contactJTextField.getText()));
//            helper.setSSN(Integer.parseInt(ssnJTextField.getText()));
//            nameJTextField.setText("");
//            addressJTextField.setText("");
//            contactJTextField.setText("");
//            ssnJTextField.setText("");
//            JOptionPane.showMessageDialog(null,"Person added successfully");
//        }
//        
//        else{
//        
//        JOptionPane.showMessageDialog(null,"Not Added");
//        }
//        
        
    }//GEN-LAST:event_addJButtonActionPerformed

    private void backJButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backJButtonActionPerformed

        userProcessContainer.remove(this);
        CardLayout layout = (CardLayout) userProcessContainer.getLayout();
        layout.previous(userProcessContainer);
    }//GEN-LAST:event_backJButtonActionPerformed

    private void organizationJComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_organizationJComboBoxActionPerformed
        Organization organization = (Organization) organizationJComboBox.getSelectedItem();
        if (organization != null){
            populateTable(organization);
        }
    }//GEN-LAST:event_organizationJComboBoxActionPerformed

    private void organizationEmpJComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_organizationEmpJComboBoxActionPerformed
       if(organizationEmpJComboBox.getSelectedItem() != null){
        Organization organization = (Organization) organizationEmpJComboBox.getSelectedItem();
        if(organization.getName().equalsIgnoreCase("FoodChecking Organization"))
        {
            nameJTextField.setEnabled(true);
            contactJTextField.setEnabled(true);
            addressJTextField.setEnabled(true);
            ssnJTextField.setEnabled(true);
           
        }
//        if(organization.getName().equalsIgnoreCase("RestaurantOrganization"))
//        {
//            rAddressJTextBox.setEnabled(true);
//            rContactJTextField.setEnabled(true);
//            rEmailJTextBox.setEnabled(true);
//            rManagerJTextBox.setEnabled(true);
//            rNameJTextField.setEnabled(true);
//            nameJTextField.setEnabled(false);
//            contactJTextField.setEnabled(false);
//            addressJTextField.setEnabled(false);
//            ssnJTextField.setEnabled(false);
//        }
       }
    }//GEN-LAST:event_organizationEmpJComboBoxActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addJButton;
    private javax.swing.JTextField addressJTextField;
    private javax.swing.JButton backJButton;
    private javax.swing.JTextField contactJTextField;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField nameJTextField;
    private javax.swing.JComboBox organizationEmpJComboBox;
    private javax.swing.JComboBox organizationJComboBox;
    private javax.swing.JTable organizationJTable;
    private javax.swing.JTextField ssnJTextField;
    // End of variables declaration//GEN-END:variables
}
