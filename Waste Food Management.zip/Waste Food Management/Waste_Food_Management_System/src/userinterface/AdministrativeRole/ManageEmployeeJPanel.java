/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package UserInterface.AdministrativeRole;

import Business.Driver.Driver;
import Business.Employee.Employee;
import static Business.Enterprise.Enterprise.EnterpriseType.Food_Source;
import Business.Helper.Helper;
import Business.Homeless.HomelessPeople;
import Business.Organization.Organization;
import Business.Organization.OrganizationDirectory;
import Business.Homeless.HomelessPeopleDirectory;
import Business.NormalUser.NormalPeople;
import Business.Organization.Organization.Type;
import Business.Restaurant.Restaurant;
import Business.Restaurant.RestaurantDirectory;
import java.awt.CardLayout;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import Business.Validation.EmailValidator;
import java.awt.event.KeyEvent;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Shubham
 */
public class ManageEmployeeJPanel extends javax.swing.JPanel {

    private OrganizationDirectory organizationDir;
    private RestaurantDirectory restaurantDirectory;
    private HomelessPeopleDirectory homelessPeopleDirectory;
    private JPanel userProcessContainer;
    private int i=1;
    
    /**
     * Creates new form ManageOrganizationJPanel
     */
    public ManageEmployeeJPanel(JPanel userProcessContainer,OrganizationDirectory organizationDir) {
        initComponents();
        this.userProcessContainer = userProcessContainer;
        this.organizationDir = organizationDir;
        this.homelessPeopleDirectory = homelessPeopleDirectory;
       
        populateOrganizationComboBox();
        populateOrganizationEmpComboBox();
    }
    
    public void populateOrganizationComboBox(){
        organizationJComboBox.removeAllItems();
        
        for (Organization organization : organizationDir.getOrganizationList()){
            organizationJComboBox.addItem(organization);
        }
    }
    
    public void populateOrganizationEmpComboBox(){
        organizationEmpJComboBox.removeAllItems();
        
        for (Organization organization : organizationDir.getOrganizationList()){
            organizationEmpJComboBox.addItem(organization);
        }
    }

    private void populateTable(Organization organization){
        DefaultTableModel model = (DefaultTableModel) organizationJTable.getModel();
        
        model.setRowCount(0);
        
        if(organization.getName().equalsIgnoreCase("RestaurantOrganization"))
        {
            if(organization.getRestaurantDirectory().getRestaurantDirectory().size() != 0){
            for (Restaurant restaurant : organization.getRestaurantDirectory().getRestaurantDirectory())
            {
                Object[] row= new Object[2];
                row[0]= restaurant.getId();
                row[1]= restaurant.getResName();
                model.addRow(row);
            }
            }
        }
        
        for (Employee employee : organization.getEmployeeDirectory().getEmployeeList()){
            Object[] row = new Object[2];
            
            if(organization.getName().equalsIgnoreCase("HomelessPeople Organization"))
            {
                row[0] = employee.homelessPeopleCount();
                
            }
            if(organization.getName().equalsIgnoreCase("NormalPeople Organization"))
            {
                row[0] = employee.normalPeopleCount();
            }
            if(organization.getName().equalsIgnoreCase("Driver Organization"))
            {
                row[0] = employee.driverCount();
                
            }
            if(organization.getName().equalsIgnoreCase("Helper Organization"))
            {
                row[0] = employee.helperCount();
            }
            row[1] = employee.getName();
            
            model.addRow(row);
        }
//        if(organization.getName().equalsIgnoreCase("Driver Organization"))
//        {
//        for (Driver driver : organization.getDriverDirectory().getDriverDirectory()){
//            Object[] row = new Object[2];
//            row[0] = driver.getId();
//            row[1] = driver.getName();
//            model.addRow(row);
//        }
//        if(organization.getName().equalsIgnoreCase("Helper Organization"))
//        {
//        for (Helper helper : organization.getHelperDirectory().getHelperDirectory()){
//            Object[] row = new Object[2];
//            row[0] = helper.getId();
//            row[1] = helper.getName();
//            model.addRow(row);  
//        }
//        if(organization.getName().equalsIgnoreCase("NormalPeople Organization"))
//        {
//        for (NormalPeople normalPeople : organization.getNormalPeoplwDirectory().getNormalPeopleDirecory())
//            {
//            Object[] row = new Object[2];
//            row[0] = normalPeople.getId();
//            row[1] = normalPeople.getName();
//            model.addRow(row);
//            }
//        }
//        if(organization.getName().equalsIgnoreCase("HomelessPeople Organization"))
//        {
//        for(HomelessPeople homelessPeople: organization.getHomelessPeopleDirectory().getHomeLessPeopleDirecory())
//        {
//            Object[] row = new Object[2];
//            row[0] = homelessPeople.getId();
//            row[1] = homelessPeople.getName();
//            model.addRow(row);
//            
//        }
//        }
//        
//        }
//        }
        
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        organizationJTable = new javax.swing.JTable();
        addJButton = new javax.swing.JButton();
        organizationJComboBox = new javax.swing.JComboBox();
        jLabel1 = new javax.swing.JLabel();
        backJButton = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        nameJTextField = new javax.swing.JTextField();
        organizationEmpJComboBox = new javax.swing.JComboBox();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        contactJTextField = new javax.swing.JTextField();
        addressJTextField = new javax.swing.JTextField();
        ssnJTextField = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        rEmailJTextBox = new javax.swing.JTextField();
        rContactJTextField = new javax.swing.JTextField();
        rManagerJTextBox = new javax.swing.JTextField();
        rAddressJTextBox = new javax.swing.JTextField();
        rNameJTextField = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();

        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        organizationJTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "ID", "Name"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(organizationJTable);
        if (organizationJTable.getColumnModel().getColumnCount() > 0) {
            organizationJTable.getColumnModel().getColumn(0).setResizable(false);
            organizationJTable.getColumnModel().getColumn(1).setResizable(false);
        }

        add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 40, 660, 92));

        addJButton.setText("Create User");
        addJButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addJButtonActionPerformed(evt);
            }
        });
        add(addJButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 480, -1, -1));

        organizationJComboBox.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        organizationJComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                organizationJComboBoxActionPerformed(evt);
            }
        });
        add(organizationJComboBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 40, 184, -1));

        jLabel1.setText("Organization");
        add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 40, -1, -1));

        backJButton.setText("<< Back");
        backJButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backJButtonActionPerformed(evt);
            }
        });
        add(backJButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 480, -1, -1));

        jLabel2.setText("Name");
        add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 280, -1, -1));

        nameJTextField.setBackground(new java.awt.Color(204, 204, 255));
        nameJTextField.setEnabled(false);
        nameJTextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                nameJTextFieldKeyTyped(evt);
            }
        });
        add(nameJTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 280, 187, -1));

        organizationEmpJComboBox.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        organizationEmpJComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                organizationEmpJComboBoxActionPerformed(evt);
            }
        });
        add(organizationEmpJComboBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 170, 187, -1));

        jLabel3.setText("Organization");
        add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 170, -1, -1));

        jLabel4.setText("Contact No.");
        add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 310, 89, -1));

        jLabel5.setText("SSN no.");
        add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 350, -1, -1));

        jLabel6.setText("Address");
        add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 390, -1, -1));

        contactJTextField.setBackground(new java.awt.Color(204, 204, 255));
        contactJTextField.setEnabled(false);
        contactJTextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                contactJTextFieldKeyTyped(evt);
            }
        });
        add(contactJTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 310, 187, -1));

        addressJTextField.setBackground(new java.awt.Color(204, 204, 255));
        addressJTextField.setEnabled(false);
        add(addressJTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 390, 187, -1));

        ssnJTextField.setBackground(new java.awt.Color(204, 204, 255));
        ssnJTextField.setEnabled(false);
        ssnJTextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                ssnJTextFieldKeyTyped(evt);
            }
        });
        add(ssnJTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 350, 187, -1));

        jLabel7.setText("Restaurant Name");
        add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 280, -1, -1));

        jLabel8.setText("Manager Name");
        add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 360, -1, -1));

        jLabel9.setText("Contact No.");
        add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 400, -1, -1));

        jLabel10.setText("Address");
        add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 320, -1, -1));

        jLabel11.setText("EmailId");
        add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 430, -1, -1));

        rEmailJTextBox.setBackground(new java.awt.Color(204, 204, 255));
        rEmailJTextBox.setEnabled(false);
        add(rEmailJTextBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 430, 190, -1));

        rContactJTextField.setBackground(new java.awt.Color(204, 204, 255));
        rContactJTextField.setEnabled(false);
        rContactJTextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                rContactJTextFieldKeyTyped(evt);
            }
        });
        add(rContactJTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 400, 190, -1));

        rManagerJTextBox.setBackground(new java.awt.Color(204, 204, 255));
        rManagerJTextBox.setEnabled(false);
        rManagerJTextBox.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                rManagerJTextBoxKeyTyped(evt);
            }
        });
        add(rManagerJTextBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 360, 190, -1));

        rAddressJTextBox.setBackground(new java.awt.Color(204, 204, 255));
        rAddressJTextBox.setEnabled(false);
        rAddressJTextBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rAddressJTextBoxActionPerformed(evt);
            }
        });
        add(rAddressJTextBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 320, 190, -1));

        rNameJTextField.setBackground(new java.awt.Color(204, 204, 255));
        rNameJTextField.setEnabled(false);
        rNameJTextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                rNameJTextFieldKeyTyped(evt);
            }
        });
        add(rNameJTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 280, 190, -1));

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel12.setText("Add Restaurant below");
        add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 210, 200, -1));

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel13.setText("Add Users below");
        add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 210, 200, -1));

        jButton1.setText("Create Restaurant");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 490, 130, -1));
    }// </editor-fold>//GEN-END:initComponents

    private void addJButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addJButtonActionPerformed
        Organization organization = (Organization) organizationEmpJComboBox.getSelectedItem();
        //String name = nameJTextField.getText();
         if (!(contactJTextField.getText().length()==10))
        {
        JOptionPane.showMessageDialog(null,"Contact must contain 10 digits");
        return;
        }
        
        try{
        if(!addressJTextField.getText().isEmpty()&&!nameJTextField.getText().isEmpty()&&!contactJTextField.getText().isEmpty()
                &&!ssnJTextField.getText().isEmpty())
        {
        Employee employee = organization.getEmployeeDirectory().createEmployee();
        employee.setAddress(addressJTextField.getText());
        employee.setName(nameJTextField.getText());
        employee.setContact(Integer.parseInt(contactJTextField.getText()));
        employee.setSsn(Integer.parseInt(ssnJTextField.getText()));
        JOptionPane.showMessageDialog(null, "User added successfully");
        addressJTextField.setText("");
        nameJTextField.setText("");
        contactJTextField.setText("");
        ssnJTextField.setText("");
        }
        
        else{
        JOptionPane.showMessageDialog(null,"Please enter all the fields");
        }
        }
        catch(Exception ex)
        {System.out.println(ex);
        }
        
//       if(organization.getName().equalsIgnoreCase("HomelessPeople Organization")) 
//       {
//            HomelessPeople homelessPeople= organization.getHomelessPeopleDirectory().addHomeLessPeople();
//            homelessPeople.setName(nameJTextField.getText());
//            homelessPeople.setContact(Integer.parseInt(contactJTextField.getText()));
//            homelessPeople.setAddress(addressJTextField.getText());
//            homelessPeople.setSSN(Integer.parseInt(ssnJTextField.getText()));
//            
//            //JOptionPane.showMessageDialog(null,"Added successfully");
//            nameJTextField.setText("");
//            addressJTextField.setText("");
//            contactJTextField.setText("");
//            ssnJTextField.setText("");
//            
//            JOptionPane.showMessageDialog(null,"Person added successfully");
//        }
//        if(organization.getName().equalsIgnoreCase("NormalPeople Organization"))
//        {
//            NormalPeople normalPeople = organization.getNormalPeoplwDirectory().addNormalPeople();
//            normalPeople.setName(nameJTextField.getText());
//            normalPeople.setAddress(addressJTextField.getText());
//            normalPeople.setContact(Integer.parseInt(contactJTextField.getText()));
//            normalPeople.setSSN(Integer.parseInt(ssnJTextField.getText()));
//            nameJTextField.setText("");
//            addressJTextField.setText("");
//            contactJTextField.setText("");
//            ssnJTextField.setText("");
//            JOptionPane.showMessageDialog(null,"Person added successfully");
//            
//        }
//        if(organization.getName().equals("Driver Organization"))
//        {
//            Driver driver = organization.getDriverDirectory().addDriver();
//            driver.setName(nameJTextField.getText());
//            driver.setAddress(addressJTextField.getText());
//            driver.setContact(Integer.parseInt(contactJTextField.getText()));
//            driver.setSSN(Integer.parseInt(ssnJTextField.getText()));
//            nameJTextField.setText("");
//            addressJTextField.setText("");
//            contactJTextField.setText("");
//            ssnJTextField.setText("");
//            JOptionPane.showMessageDialog(null,"Person added successfully");
//        
//        }
//        if(organization.getName().equalsIgnoreCase("Helper Organization"))
//        {
//            Helper helper = organization.getHelperDirectory().addHelper();
//            helper.setAddress(addressJTextField.getText());
//            helper.setContact(Integer.parseInt(contactJTextField.getText()));
//            helper.setSSN(Integer.parseInt(ssnJTextField.getText()));
//            nameJTextField.setText("");
//            addressJTextField.setText("");
//            contactJTextField.setText("");
//            ssnJTextField.setText("");
//            JOptionPane.showMessageDialog(null,"Person added successfully");
//        }
//        
//        else{
//        
//        JOptionPane.showMessageDialog(null,"Not Added");
//        }
//        
        
    }//GEN-LAST:event_addJButtonActionPerformed

    private void backJButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backJButtonActionPerformed

        userProcessContainer.remove(this);
        CardLayout layout = (CardLayout) userProcessContainer.getLayout();
        layout.previous(userProcessContainer);
    }//GEN-LAST:event_backJButtonActionPerformed

    private void organizationJComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_organizationJComboBoxActionPerformed
        Organization organization = (Organization) organizationJComboBox.getSelectedItem();
        if (organization != null){
            populateTable(organization);
        }
    }//GEN-LAST:event_organizationJComboBoxActionPerformed

    private void organizationEmpJComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_organizationEmpJComboBoxActionPerformed
       if(organizationEmpJComboBox.getSelectedItem() != null){
        Organization organization = (Organization) organizationEmpJComboBox.getSelectedItem();
        if(organization.getName().equalsIgnoreCase("HomelessPeople Organization") || organization.getName().equalsIgnoreCase("Driver Organization")
                || organization.getName().equalsIgnoreCase("Helper Organization") || organization.getName().equalsIgnoreCase("NormalPeople Organization"))
        {
            nameJTextField.setEnabled(true);
            contactJTextField.setEnabled(true);
            addressJTextField.setEnabled(true);
            ssnJTextField.setEnabled(true);
            rAddressJTextBox.setEnabled(false);
            rContactJTextField.setEnabled(false);
            rEmailJTextBox.setEnabled(false);
            rManagerJTextBox.setEnabled(false);
            rNameJTextField.setEnabled(false);
        }
        if(organization.getName().equalsIgnoreCase("RestaurantOrganization"))
        {
            rAddressJTextBox.setEnabled(true);
            rContactJTextField.setEnabled(true);
            rEmailJTextBox.setEnabled(true);
            rManagerJTextBox.setEnabled(true);
            rNameJTextField.setEnabled(true);
            nameJTextField.setEnabled(false);
            contactJTextField.setEnabled(false);
            addressJTextField.setEnabled(false);
            ssnJTextField.setEnabled(false);
        }
       }
       
    }//GEN-LAST:event_organizationEmpJComboBoxActionPerformed

    private void rAddressJTextBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rAddressJTextBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rAddressJTextBoxActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
      Organization organization = (Organization) organizationEmpJComboBox.getSelectedItem();
      try{ 
      if (!(rContactJTextField.getText().length()==10))
        {
        JOptionPane.showMessageDialog(null,"Contact must contain 10 digits");
        return;
        }
        EmailValidator emailValidator = new EmailValidator();
             if(!emailValidator.validate(rEmailJTextBox.getText().trim()))
             {
                 JOptionPane.showMessageDialog(null, "Email is not valid");
                 return;
             }
       
      if(!rAddressJTextBox.getText().isEmpty()&&!rContactJTextField.getText().isEmpty()&&!rEmailJTextBox.getText().isEmpty()
                &&!rManagerJTextBox.getText().isEmpty()&&!rNameJTextField.getText().isEmpty())
        {
      Restaurant restaurant = organization.getRestaurantDirectory().addRestaurant();
      restaurant.setResAddress(rAddressJTextBox.getText());
      restaurant.setResContact(Integer.parseInt(rContactJTextField.getText()));
      restaurant.setResEmailId(rEmailJTextBox.getText());
      restaurant.setResManagerName(rManagerJTextBox.getText());
      restaurant.setResName(rNameJTextField.getText());
      JOptionPane.showMessageDialog(null,"Restaurant added successfully");
      
      rAddressJTextBox.setText("");
      rContactJTextField.setText("");
      rEmailJTextBox.setText("");
      rManagerJTextBox.setText("");
      rNameJTextField.setText("");
        }
      else{
        JOptionPane.showMessageDialog(null,"Please enter all the fields");
        }
      }
      catch(Exception e)
      {
          System.out.println(e);
       }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void contactJTextFieldKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_contactJTextFieldKeyTyped
        char c= evt.getKeyChar();
        if(!(Character.isDigit(c) || (c==KeyEvent.VK_BACK_SPACE) || c== KeyEvent.VK_DELETE))
        {
            getToolkit().beep();
            evt.consume();
        }
        
    }//GEN-LAST:event_contactJTextFieldKeyTyped

    private void rContactJTextFieldKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_rContactJTextFieldKeyTyped
        char c= evt.getKeyChar();
        if(!(Character.isDigit(c) || (c==KeyEvent.VK_BACK_SPACE) || c== KeyEvent.VK_DELETE))
        {
            getToolkit().beep();
            evt.consume();
        }
        
    }//GEN-LAST:event_rContactJTextFieldKeyTyped

    private void ssnJTextFieldKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ssnJTextFieldKeyTyped
        char c= evt.getKeyChar();
        if(!(Character.isDigit(c) || (c==KeyEvent.VK_BACK_SPACE) || c== KeyEvent.VK_DELETE))
        {
            getToolkit().beep();
            evt.consume();
        }
        
    }//GEN-LAST:event_ssnJTextFieldKeyTyped

    private void nameJTextFieldKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_nameJTextFieldKeyTyped
         char c= evt.getKeyChar();
        if(!(Character.isLetter(c) || (c==KeyEvent.VK_BACK_SPACE) || c== KeyEvent.VK_DELETE))
        {
            getToolkit().beep();
            evt.consume();
        } 
    }//GEN-LAST:event_nameJTextFieldKeyTyped

    private void rManagerJTextBoxKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_rManagerJTextBoxKeyTyped
        char c= evt.getKeyChar();
        if(!(Character.isLetter(c) || (c==KeyEvent.VK_BACK_SPACE) || c== KeyEvent.VK_DELETE))
        {
            getToolkit().beep();
            evt.consume();
        } 
    }//GEN-LAST:event_rManagerJTextBoxKeyTyped

    private void rNameJTextFieldKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_rNameJTextFieldKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_rNameJTextFieldKeyTyped

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addJButton;
    private javax.swing.JTextField addressJTextField;
    private javax.swing.JButton backJButton;
    private javax.swing.JTextField contactJTextField;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField nameJTextField;
    private javax.swing.JComboBox organizationEmpJComboBox;
    private javax.swing.JComboBox organizationJComboBox;
    private javax.swing.JTable organizationJTable;
    private javax.swing.JTextField rAddressJTextBox;
    private javax.swing.JTextField rContactJTextField;
    private javax.swing.JTextField rEmailJTextBox;
    private javax.swing.JTextField rManagerJTextBox;
    private javax.swing.JTextField rNameJTextField;
    private javax.swing.JTextField ssnJTextField;
    // End of variables declaration//GEN-END:variables
}
