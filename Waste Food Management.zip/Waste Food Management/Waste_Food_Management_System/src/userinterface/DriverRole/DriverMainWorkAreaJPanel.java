/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package userinterface.DriverRole;

import Business.Driver.Driver;
import Business.Employee.Employee;
import Business.Enterprise.Enterprise;
import Business.LeftFood.LeftFood;
import Business.Organization.DriverOrganization;
import Business.Organization.HelperOrganization;
import Business.Organization.Organization;
import Business.Restaurant.Restaurant;
import Business.UserAccount.UserAccount;
import Business.WorkQueue.WorkRequest;
import java.awt.CardLayout;
import java.io.IOException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;
import userinterface.DistributionInformation.HomelessPeopleJPanel;

/**
 *
 * @author Pawan
 */
public class DriverMainWorkAreaJPanel extends javax.swing.JPanel {

    JPanel userProcessContainer;
    UserAccount account;
    DriverOrganization driverOrganization;
    HelperOrganization helperOrganization;
    Enterprise enterprise;
    Organization organization;
    int j,k;
    public DriverMainWorkAreaJPanel(JPanel userProcessContainer, UserAccount account, DriverOrganization driverOrganization, Enterprise enterprise) {
        initComponents();
        this.userProcessContainer = userProcessContainer;
        this.account = account;
        this.driverOrganization = driverOrganization;
        this.enterprise = enterprise;
        this.helperOrganization = helperOrganization;
        this.organization = organization;

            populateDriverTable();

    }

    public void populateDriverTable() {
        try {
            DefaultTableModel model = (DefaultTableModel) driverJTable.getModel();

            model.setRowCount(0);
           
            for (WorkRequest wr : driverOrganization.getWorkQueue().getWorkRequestList()) {
                for (LeftFood lf : wr.getRestaurant().getLeftFoodDirectory()) {
//               LeftFood l = (LeftFood) driverJTable.getValueAt(driverJTable.getSelectedRow(),3);
//               if(l.getPickupTime().equalsIgnoreCase(lf.getPickupTime()))
//            
//               {       
                    Object[] row = new Object[9];
                    row[0] = wr.getRestaurant();
                    row[1] = wr.getRestaurant().getResAddress();
                    row[2] = lf.getPickupTime();
                    row[3] = lf.getPickupDate();
                    row[4] = lf.getDistributionLocation();
                    row[5] = lf.getDistributionTime();
                    row[6] = wr.getRestaurant().getResContact();
                    row[7] = wr.getReceiver() == null ? null : wr.getReceiver().getEmployee().getName();
                    row[8] = wr;

                    model.addRow(row);
                    //       }
                }
            
            
            }
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }

    public void populateDriverTable1() {
        try {
            DefaultTableModel model = (DefaultTableModel) driverJTable.getModel();

            
            int i = driverJTable.getSelectedRow();
            if (i < 0) {
                JOptionPane.showMessageDialog(null, "Please select a row");

            } else {
                for (WorkRequest wr : driverOrganization.getWorkQueue().getWorkRequestList()) {
                    for (LeftFood lf : wr.getRestaurant().getLeftFoodDirectory()) {
                        String time = (String) driverJTable.getValueAt(driverJTable.getSelectedRow(), 2);
                        if (time.equalsIgnoreCase(lf.getPickupTime())) {
                            Object[] row = new Object[9];
                            row[0] = wr.getRestaurant();
                            row[1] = wr.getRestaurant().getResAddress();
                            row[2] = lf;
                            row[3] = lf.getPickupDate();
                            row[4] = lf.getDistributionLocation();
                            row[5] = lf.getDistributionTime();
                            row[6] = wr.getRestaurant().getResContact();
                            row[7] = wr.getReceiver() == null ? null : wr.getReceiver().getEmployee().getName();
                            row[8] = wr;

                            model.addRow(row);
                        }
                    }
                }
            }
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        driverJTable = new javax.swing.JTable();
        jButton2 = new javax.swing.JButton();
        mapJButton = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        foodAfterDistributionJTextField = new javax.swing.JTextField();
        sendremainingQuantityJButton = new javax.swing.JButton();
        getHelperBtn = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();

        driverJTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Restaurant_Name", "PickUpLocation", "PickUpDate", "PickUpTime", "DistributionLocation", "DistributionTime", "Contact", "Receiver", "Message"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(driverJTable);
        if (driverJTable.getColumnModel().getColumnCount() > 0) {
            driverJTable.getColumnModel().getColumn(0).setResizable(false);
            driverJTable.getColumnModel().getColumn(1).setResizable(false);
            driverJTable.getColumnModel().getColumn(2).setResizable(false);
            driverJTable.getColumnModel().getColumn(3).setResizable(false);
            driverJTable.getColumnModel().getColumn(4).setResizable(false);
            driverJTable.getColumnModel().getColumn(5).setResizable(false);
            driverJTable.getColumnModel().getColumn(6).setResizable(false);
            driverJTable.getColumnModel().getColumn(7).setResizable(false);
            driverJTable.getColumnModel().getColumn(8).setResizable(false);
        }

        jButton2.setText("Assign To Me");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        mapJButton.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        mapJButton.setText("Use map to search location");
        mapJButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mapJButtonActionPerformed(evt);
            }
        });

        jButton3.setText("Email");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jLabel1.setText("Send request acceptance email to admin :");

        jLabel2.setText("Left food after distribution (Quantity in Kg) :");

        sendremainingQuantityJButton.setText("Send");
        sendremainingQuantityJButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sendremainingQuantityJButtonActionPerformed(evt);
            }
        });

        getHelperBtn.setText("Get Helper");
        getHelperBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                getHelperBtnActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel3.setText("Normal people will get food after 1 hour of the distribution time");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jScrollPane1)
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(48, 48, 48)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(64, 64, 64)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(foodAfterDistributionJTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(sendremainingQuantityJButton)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(193, Short.MAX_VALUE)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 589, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(237, 237, 237))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(181, 181, 181)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(mapJButton)
                    .addComponent(getHelperBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(131, 131, 131))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(43, 43, 43)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(113, 113, 113)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton3)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(31, 31, 31)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(foodAfterDistributionJTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(sendremainingQuantityJButton)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(204, 204, 204)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton2)
                            .addComponent(getHelperBtn))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 29, Short.MAX_VALUE)
                .addComponent(mapJButton, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(79, 79, 79))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        try {
            int i = driverJTable.getSelectedRow();
            if (i < 0) {
                JOptionPane.showMessageDialog(null, "Please select a row");

            } else {
                WorkRequest wr = (WorkRequest) driverJTable.getValueAt(i, 8);
                wr.setReceiver(account);
                populateDriverTable();
            }
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void mapJButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mapJButtonActionPerformed
        try {
            String URL = "https://www.google.com/maps/@42.3398067,-71.0913604,17z";
            java.awt.Desktop.getDesktop().browse(java.net.URI.create(URL));
        } catch (IOException ex) {
            Logger.getLogger(HomelessPeopleJPanel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_mapJButtonActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        Properties props = new Properties();
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.socketFactory.port", "465");
        props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.port", "465");

        Session session = Session.getInstance(props,
                new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication("patidarpawan08@gmail.com", "9926677997");
            }
        }
        );
        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress("patidarpawan08@gmail.com"));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse("patidarpawan08@gmail.com"));
            message.setSubject("Request Accepted");
            message.setText("Hello...!!!!!");
            Transport.send(message);

            JOptionPane.showMessageDialog(null, "Email sent successfully");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void sendremainingQuantityJButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sendremainingQuantityJButtonActionPerformed
        int i = driverJTable.getSelectedRow();
        
        if (i < 0) {
            JOptionPane.showMessageDialog(null, "Please select a row from the table");
        } else {
            
                Employee e = account.getEmployee();
             
                j = e.getLeftFoodAfterDist();
                k = j+ Integer.parseInt(foodAfterDistributionJTextField.getText());
                e.setLeftFoodAfterDist(k);
       
        }

    }//GEN-LAST:event_sendremainingQuantityJButtonActionPerformed

    private void getHelperBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_getHelperBtnActionPerformed
        GetHelperWorkAreaJPanel ghwajp = new GetHelperWorkAreaJPanel( userProcessContainer,  account,  helperOrganization,  enterprise);
        userProcessContainer.add("GetHelperWorkAreaJPanel",ghwajp);
        CardLayout layout = (CardLayout) userProcessContainer.getLayout();
        layout.next(userProcessContainer);
    }//GEN-LAST:event_getHelperBtnActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable driverJTable;
    private javax.swing.JTextField foodAfterDistributionJTextField;
    private javax.swing.JButton getHelperBtn;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton mapJButton;
    private javax.swing.JButton sendremainingQuantityJButton;
    // End of variables declaration//GEN-END:variables
}
