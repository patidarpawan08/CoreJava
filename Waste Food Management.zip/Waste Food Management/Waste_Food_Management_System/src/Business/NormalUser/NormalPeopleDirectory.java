/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.NormalUser;


import java.util.ArrayList;

/**
 *
 * @author Pawan
 */
public class NormalPeopleDirectory {
    private ArrayList<NormalPeople> normalPeopleDirecory;
    
    public NormalPeopleDirectory()
    {
        this.normalPeopleDirecory = new ArrayList<NormalPeople>();
         
    }
    
    public ArrayList<NormalPeople> getNormalPeopleDirecory() {
        return normalPeopleDirecory;
    }

    public void setNormalPeopleDirecory(ArrayList<NormalPeople> normalPeopleDirecory) {
        this.normalPeopleDirecory = normalPeopleDirecory;
    }
    
    public NormalPeople addNormalPeople()
    {
        NormalPeople normalPeople= new NormalPeople();
        normalPeopleDirecory.add(normalPeople);
        return normalPeople;
    }
    
    public void deleteNormalPeople(NormalPeople normalPeople)
    {
        normalPeopleDirecory.remove(normalPeople);
    }
    
    
}
