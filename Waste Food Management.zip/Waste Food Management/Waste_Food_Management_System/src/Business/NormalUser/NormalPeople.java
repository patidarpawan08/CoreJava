/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.NormalUser;

import Business.Person.Person;
import java.util.Date;
import sun.security.util.Password;

/**
 *
 * @author Pawan
 */
public class NormalPeople extends Person{
    private String personType;
    
    private int id;
   private String distLocation;
   private String distdate;
   private String disttime;
    private static int count=1;
    public NormalPeople()
    {
     id= count;
     count++;
    }

    public String getDistLocation() {
        return distLocation;
    }

    public void setDistLocation(String distLocation) {
        this.distLocation = distLocation;
    }

    public String getDistdate() {
        return distdate;
    }

    public void setDistdate(String distdate) {
        this.distdate = distdate;
    }


    public String getDisttime() {
        return disttime;
    }

    public void setDisttime(String disttime) {
        this.disttime = disttime;
    }

    public int getId() {
        return id;
    }

   
}
