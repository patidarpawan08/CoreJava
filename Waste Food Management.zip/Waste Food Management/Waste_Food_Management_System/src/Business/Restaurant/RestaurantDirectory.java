/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Restaurant;

import java.util.ArrayList;

/**
 *
 * @author Pawan
 */
public class RestaurantDirectory {
    private ArrayList<Restaurant> restaurantDirectory;
    
    public RestaurantDirectory()
    {
        this.restaurantDirectory = new ArrayList<Restaurant>();
    }

    public ArrayList<Restaurant> getRestaurantDirectory() {
        return restaurantDirectory;
    }

    public void setRestaurantDirectory(ArrayList<Restaurant> restaurantDirectory) {
        this.restaurantDirectory = restaurantDirectory;
    }
    
    public Restaurant addRestaurant()
    {
        Restaurant restaurant = new Restaurant();
        restaurantDirectory.add(restaurant);
        return restaurant;
    }
}
