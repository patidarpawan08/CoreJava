/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Restaurant;

import Business.LeftFood.LeftFood;
import Business.LeftFood.LeftFoodDirectory;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Pawan
 */
public class Restaurant {
    private String resName;
    private String resAddress;
    private String resManagerName;
    private int resContact;
    private String resEmailId;
    private int quantity;
    private List<LeftFood> leftFoodDirectory;
    private String pickupDate;
    private String pickupTime;
    
    private int id;
    private static int count = 1;
    
    public Restaurant()
    {
    id = count;
        count++;
        this.leftFoodDirectory = new ArrayList<LeftFood>();
        
    }

    public String getResName() {
        return resName;
    }

    public void setResName(String resName) {
        this.resName = resName;
    }

    public String getResAddress() {
        return resAddress;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getPickupDate() {
        return pickupDate;
    }

    public void setPickupDate(String pickupDate) {
        this.pickupDate = pickupDate;
    }

    public String getPickupTime() {
        return pickupTime;
    }

    public void setPickupTime(String pickupTime) {
        this.pickupTime = pickupTime;
    }

    public void setResAddress(String resAddress) {
        this.resAddress = resAddress;
    }

    public String getResManagerName() {
        return resManagerName;
    }
    

    public void setResManagerName(String resManagerName) {
        this.resManagerName = resManagerName;
    }

    public int getResContact() {
        return resContact;
    }

    public void setResContact(int resContact) {
        this.resContact = resContact;
    }


    public String getResEmailId() {
        return resEmailId;
    }

    public void setResEmailId(String resEmailId) {
        this.resEmailId = resEmailId;
    }

    public int getId() {
        return id;
    }

    public List<LeftFood> getLeftFoodDirectory() {
        return leftFoodDirectory;
    }

    public void setLeftFoodDirectory(List<LeftFood> leftFoodDirectory) {
        this.leftFoodDirectory = leftFoodDirectory;
    }

    
    
 @Override
    public String toString()
    {
     return this.getResName();
    }
    
    
    
}
