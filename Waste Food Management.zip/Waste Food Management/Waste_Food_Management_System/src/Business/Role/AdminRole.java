/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Role;

import Business.EcoSystem;
import Business.Enterprise.Enterprise;
import Business.Organization.Organization;
import Business.UserAccount.UserAccount;
import javax.swing.JPanel;
import UserInterface.AdministrativeRole.AdminWorkAreaJPanel;
import userinterface.FoodChekerRole.FoodCheckerAdminWorkAreaJPanel;

/**
 *
 * @author Shubham
 */
public class AdminRole extends Role {

    @Override
    public JPanel createWorkArea(JPanel userProcessContainer, UserAccount account, Organization organization, Enterprise enterprise, EcoSystem business) {
      for (Organization.Type type : Organization.Type.values()) {

            if (enterprise.getEnterpriseType() == Enterprise.EnterpriseType.Food_Source) {
                return new AdminWorkAreaJPanel(userProcessContainer, organization,account, enterprise, business);
            }
            else if (enterprise.getEnterpriseType() == Enterprise.EnterpriseType.Food_Checking) {
                return new FoodCheckerAdminWorkAreaJPanel(userProcessContainer, enterprise,business);
            }
             
        }
        return null;
    }
    
    
}
