/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Homeless;

import Business.NormalUser.NormalPeople;
import java.util.ArrayList;

/**
 *
 * @author Pawan
 */
public class HomelessPeopleDirectory {
    private ArrayList<HomelessPeople> homeLessPeopleDirecory;

    public ArrayList<HomelessPeople> getHomeLessPeopleDirecory() {
        return homeLessPeopleDirecory;
    }

    public void setHomeLessPeopleDirecory(ArrayList<HomelessPeople> homeLessPeopleDirecory) {
        this.homeLessPeopleDirecory = homeLessPeopleDirecory;
    }
    
    public HomelessPeopleDirectory()
    {
        this.homeLessPeopleDirecory = new ArrayList<>();
         
    }
    
    public HomelessPeople addHomeLessPeople()
    {
        HomelessPeople homelessPeople= new HomelessPeople();
        homeLessPeopleDirecory.add(homelessPeople);
        return homelessPeople;
    }
    
    public void deleteHomelessPeople(HomelessPeople homelessPeople)
    {
        homeLessPeopleDirecory.remove(homelessPeople);
    }
}
