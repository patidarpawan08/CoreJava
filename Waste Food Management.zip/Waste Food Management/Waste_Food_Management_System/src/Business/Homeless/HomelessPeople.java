/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Homeless;

import Business.Person.Person;
import java.util.Date;

/**
 *
 * @author Pawan
 */
public class HomelessPeople extends Person  {
    
   private int id;
   private static int count=1;
   private String distLocation;
   private String distdate;
   private String disttime;

    public String getDistLocation() {
        return distLocation;
    }

    public void setDistLocation(String distLocation) {
        this.distLocation = distLocation;
    }

    public String getDistdate() {
        return distdate;
    }

    public void setDistdate(String distdate) {
        this.distdate = distdate;
    }


  
    public String getDisttime() {
        return disttime;
    }

    public void setDisttime(String disttime) {
        this.disttime = disttime;
    }

   public HomelessPeople()
   {
   id= count;
   count++;
   }

    public int getId() {
        return id;
    }
   
}
