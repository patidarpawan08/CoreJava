/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Helper;

import java.util.ArrayList;

/**
 *
 * @author Pawan
 */
public class HelperDirectory {
    private ArrayList<Helper> helperDirectory;
    
    public HelperDirectory()
    {
        this.helperDirectory= new ArrayList<>();
    }

    public ArrayList<Helper> getHelperDirectory() {
        return helperDirectory;
    }

    public void setHelperDirectory(ArrayList<Helper> helperDirectory) {
        this.helperDirectory = helperDirectory;
    }
    
    public Helper addHelper()
    {
        Helper helper = new Helper();
        helperDirectory.add(helper);
        return helper;
    }
    
    public void deleteHelper(Helper helper)
    {
        helperDirectory.remove(helper);
    }
}
