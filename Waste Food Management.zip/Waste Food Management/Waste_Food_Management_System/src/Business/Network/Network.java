/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Network;

import Business.Enterprise.Enterprise;
import Business.Enterprise.EnterpriseDirectory;
import Business.Organization.Organization;
import Business.UserAccount.UserAccount;

/**
 *
 * @author Shubham
 */
public class Network {
    private String name;
    
    private EnterpriseDirectory enterpriseDirectory;

    public Network() {
        enterpriseDirectory = new EnterpriseDirectory();
    }
    
    

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public EnterpriseDirectory getEnterpriseDirectory() {
        return enterpriseDirectory;
    }
    public boolean checkUsername(String name) {
        
       if(enterpriseDirectory.checkEnterpriseUserName(name)==false)
       {   
        for (Enterprise e : enterpriseDirectory.getEnterpriseList()) {
            
            for (Organization o : e.getOrganizationDirectory().getOrganizationList()) {
                for (UserAccount ua : o.getUserAccountDirectory().getUserAccountList()) {
                    if (ua.getUsername().equalsIgnoreCase(name)) {
                        return true;
                    }
                }
            }
        }
       }
       else if(enterpriseDirectory.checkEnterpriseUserName(name)==true)
       {
           return true;
       }
       
        return false;
       
    }

  
    

@Override
public String toString(){
return name;

}
    
     
    
}
