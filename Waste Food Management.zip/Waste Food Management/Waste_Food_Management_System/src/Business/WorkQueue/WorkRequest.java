/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.WorkQueue;

import Business.Driver.Driver;
import Business.Restaurant.Restaurant;
import Business.UserAccount.UserAccount;
import static com.oracle.jrockit.jfr.ContentType.Address;
import com.sun.jndi.cosnaming.IiopUrl.Address;
import java.sql.Time;
import java.util.Date;

/**
 *
 * @author Shubham
 */
public abstract class WorkRequest {
    
    private String date;
    private String message;
    private UserAccount sender;
    private UserAccount receiver;
    private String status;
    private Restaurant restaurant;
    private Address pickUpaddress;
    private Address distributingAddress;
    private Driver driver;
    private String receivedBy;
    private String pickUpTime;
    private String driverName;
    private String foodCheckingdate;
    private String foodCheckingtime;
    private String foodContact;
    private String foodResult;
    private String foodLocation;

    public String getDriverName() {
        return driverName;
    }

    public void setDriverName(String driverName) {
        this.driverName = driverName;
    }

    public String getFoodCheckingdate() {
        return foodCheckingdate;
    }

    public void setFoodCheckingdate(String foodCheckingdate) {
        this.foodCheckingdate = foodCheckingdate;
    }

    public String getFoodCheckingtime() {
        return foodCheckingtime;
    }

    public void setFoodCheckingtime(String foodCheckingtime) {
        this.foodCheckingtime = foodCheckingtime;
    }

    public String getFoodContact() {
        return foodContact;
    }

    public void setFoodContact(String foodContact) {
        this.foodContact = foodContact;
    }

    public String getFoodResult() {
        return foodResult;
    }

    public void setFoodResult(String foodResult) {
        this.foodResult = foodResult;
    }

    public String getFoodLocation() {
        return foodLocation;
    }

    public void setFoodLocation(String foodLocation) {
        this.foodLocation = foodLocation;
    }

  

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Restaurant getRestaurant() {
        return restaurant;
    }

    public void setRestaurant(Restaurant restaurant) {
        this.restaurant = restaurant;
    }

    public Driver getDriver() {
        return driver;
    }

    public void setDriver(Driver driver) {
        this.driver = driver;
    }

    public UserAccount getSender() {
        return sender;
    }

    public void setSender(UserAccount sender) {
        this.sender = sender;
    }

    public UserAccount getReceiver() {
        return receiver;
    }

    public void setReceiver(UserAccount receiver) {
        this.receiver = receiver;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Address getPickUpaddress() {
        return pickUpaddress;
    }

    public void setPickUpaddress(Address pickUpaddress) {
        this.pickUpaddress = pickUpaddress;
    }

    public Address getDistributingAddress() {
        return distributingAddress;
    }

    public void setDistributingAddress(Address distributingAddress) {
        this.distributingAddress = distributingAddress;
    }

    public String getReceivedBy() {
        return receivedBy;
    }

    public void setReceivedBy(String receivedBy) {
        this.receivedBy = receivedBy;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getPickUpTime() {
        return pickUpTime;
    }

    public void setPickUpTime(String pickUpTime) {
        this.pickUpTime = pickUpTime;
    }

       
 @Override
    public String toString()
    {
     return this.getMessage();
    }
}
