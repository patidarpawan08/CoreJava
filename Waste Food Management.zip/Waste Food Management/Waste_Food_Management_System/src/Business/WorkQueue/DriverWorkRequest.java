/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.WorkQueue;

/**
 *
 * @author Shubham
 */
public class DriverWorkRequest extends WorkRequest{
    
    private String command;
    private int remainingQuantity;

    public String getCommand() {
        return command;
    }

    public int getRemainingQuantity() {
        return remainingQuantity;
    }

    public void setRemainingQuantity(int remainingQuantity) {
        this.remainingQuantity = remainingQuantity;
    }

    public void setCommand(String command) {
        this.command = command;
    }
    
    
    
}
