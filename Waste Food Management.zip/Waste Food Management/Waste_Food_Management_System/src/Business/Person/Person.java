/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Person;

import sun.security.util.Password;

/**
 *
 * @author Pawan
 */
public class Person {
    private String name;
    private String address;
    private int contact;
    private int SSN;
    
    public Person()
    {
    
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getContact() {
        return contact;
    }

    public void setContact(int contact) {
        this.contact = contact;
    }

    public int getSSN() {
        return SSN;
    }

    public void setSSN(int SSN) {
        this.SSN = SSN;
    }

//        @Override
//    public String toString()
//    {
//     return this.getSSN()+"";
//    }
    
}
