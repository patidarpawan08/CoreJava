/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Employee;

/**
 *
 * @author Shubham
 */
public class Employee {
    private String name;
    private int ssn;
    private String address;
    private int contact;
    private int id;
    private  int homelessID=1;
    private  int normalID=1;
    private int driverID= 1;
    private int helperID= 1;
    private static int count = 1;
    private int leftFoodAfterDist;

    public int getLeftFoodAfterDist() {
        return leftFoodAfterDist;
    }

    public void setLeftFoodAfterDist(int leftFoodAfterDist) {
        this.leftFoodAfterDist = leftFoodAfterDist;
    }
    
//    public Employee(){
//    id = count;
//        count++;
//    }
    public int homelessPeopleCount()
    {
        homelessID++;
        return homelessID;
    }
    public int normalPeopleCount()
    {
        normalID++;
        return normalID;
    }
    public int driverCount()
    {
        driverID++;
        return driverID;
    }
    public int helperCount()
    {
        helperID++;
        return helperID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getContact() {
        return contact;
    }

    public void setContact(int contact) {
        this.contact = contact;
    }

    public int getSsn() {
        return ssn;
    }

    public void setSsn(int ssn) {
        this.ssn = ssn;
    }

    public int getId() {
        return id;
    }
    @Override
    public String toString()
    {
     return this.getName();
    }
    
    

   
    
    
    
}
