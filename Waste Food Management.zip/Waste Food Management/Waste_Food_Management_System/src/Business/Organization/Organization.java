/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organization;

import Business.Driver.DriverDirectory;
import Business.Employee.EmployeeDirectory;
import Business.Helper.HelperDirectory;
import Business.Homeless.HomelessPeopleDirectory;
import Business.LeftFood.LeftFoodDirectory;
import Business.NormalUser.NormalPeopleDirectory;
import Business.Restaurant.RestaurantDirectory;
import Business.Role.Role;
import Business.UserAccount.UserAccountDirectory;
import Business.WorkQueue.WorkQueue;
import java.util.ArrayList;

/**
 *
 * @author Shubham
 */
public abstract class Organization {

    private String name;
    private WorkQueue workQueue;
    private EmployeeDirectory employeeDirectory;
    private UserAccountDirectory userAccountDirectory;
    private int organizationID;
    private LeftFoodDirectory leftFoodDirectory;
    private NormalPeopleDirectory normalPeoplwDirectory;
    private HomelessPeopleDirectory homelessPeopleDirectory;
    private HelperDirectory helperDirectory;
    private RestaurantDirectory restaurantDirectory;
    private DriverDirectory driverDirectory;
    private static int counter=1;
    
    public enum Type{
        Admin("Admin Organization"), 
        HomelessPeople("HomelessPeople Organization"), 
        NormalPeople("NormalPeople Organization"),
        FoodChecking("FoodChecking Organization"),
        Driver("Driver Organization"),
        Helper("Helper Organization"),
        Restaurant("RestaurantOrganization");
        
        private String value;
        private Type(String value) {
            this.value = value;
        }
        public String getValue() {
            return value;
        }
    }

    public Organization(String name) {
        this.name = name;
        workQueue = new WorkQueue();
        employeeDirectory = new EmployeeDirectory();
        userAccountDirectory = new UserAccountDirectory();
        normalPeoplwDirectory = new NormalPeopleDirectory ();
        homelessPeopleDirectory =new HomelessPeopleDirectory ();
        helperDirectory =new HelperDirectory ();
        restaurantDirectory =new RestaurantDirectory();
        driverDirectory =new DriverDirectory ();
        leftFoodDirectory = new LeftFoodDirectory();
        organizationID = counter;
        ++counter;
    }

    public abstract ArrayList<Role> getSupportedRole();
    
    public UserAccountDirectory getUserAccountDirectory() {
        return userAccountDirectory;
    }

    public int getOrganizationID() {
        return organizationID;
    }

    public NormalPeopleDirectory getNormalPeoplwDirectory() {
        return normalPeoplwDirectory;
    }

    public LeftFoodDirectory getLeftFoodDirectory() {
        return leftFoodDirectory;
    }

    public void setLeftFoodDirectory(LeftFoodDirectory leftFoodDirectory) {
        this.leftFoodDirectory = leftFoodDirectory;
    }

    public RestaurantDirectory getRestaurantDirectory() {
        return restaurantDirectory;
    }

    public void setRestaurantDirectory(RestaurantDirectory restaurantDirectory) {
        this.restaurantDirectory = restaurantDirectory;
    }

    public HomelessPeopleDirectory getHomelessPeopleDirectory() {
        return homelessPeopleDirectory;
    }

    public HelperDirectory getHelperDirectory() {
        return helperDirectory;
    }

    public DriverDirectory getDriverDirectory() {
        return driverDirectory;
    }

    public EmployeeDirectory getEmployeeDirectory() {
        return employeeDirectory;
    }
    
    public String getName() {
        return name;
    }

    public WorkQueue getWorkQueue() {
        return workQueue;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setWorkQueue(WorkQueue workQueue) {
        this.workQueue = workQueue;
    }

    @Override
    public String toString() {
        return name;
    }
    
    
}
