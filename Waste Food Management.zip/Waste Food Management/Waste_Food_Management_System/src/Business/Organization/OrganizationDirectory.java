/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organization;

import Business.Organization.Organization.Type;
import java.util.ArrayList;

/**
 *
 * @author Shubham
 */
public class OrganizationDirectory {
    
    private ArrayList<Organization> organizationList;

    public OrganizationDirectory() {
        organizationList = new ArrayList();
    }

    public ArrayList<Organization> getOrganizationList() {
        return organizationList;
    }
    
    public Organization createOrganization(Type type){
        Organization organization = null;
        if (type.getValue().equals(Type.NormalPeople.getValue())){
            organization = new NormalPeopleOrganization();
            organizationList.add(organization);
        }
       
         else if (type.getValue().equals(Type.HomelessPeople.getValue())){
            organization = new HomelessPeopleOrganization();
            organizationList.add(organization);
        }
        else if (type.getValue().equals(Type.Driver.getValue())){
            organization = new DriverOrganization();
            organizationList.add(organization);
        }
        else if (type.getValue().equals(Type.Helper.getValue())){
            organization = new HelperOrganization();
            organizationList.add(organization);
        }
        else if (type.getValue().equals(Type.FoodChecking.getValue())){
            organization = new FoodCheckingOrganization();
            organizationList.add(organization);
        }
        else if (type.getValue().equals(Type.Restaurant.getValue())){
            organization = new RestaurantOrganization();
            organizationList.add(organization);
        }
        return organization;
    }
    
    
}