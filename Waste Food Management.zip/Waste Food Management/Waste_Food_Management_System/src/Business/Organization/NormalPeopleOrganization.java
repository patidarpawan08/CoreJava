/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organization;


import Business.Role.NormalPeopleRole;
import Business.Role.Role;
import java.util.ArrayList;

/**
 *
 * @author Shubham
 */
public class NormalPeopleOrganization extends Organization{

    public NormalPeopleOrganization() {
        super(Organization.Type.NormalPeople.getValue());
    }
    
    @Override
    public ArrayList<Role> getSupportedRole() {
        ArrayList<Role> roles = new ArrayList();
        roles.add(new NormalPeopleRole());
        return roles;
    }
     
}