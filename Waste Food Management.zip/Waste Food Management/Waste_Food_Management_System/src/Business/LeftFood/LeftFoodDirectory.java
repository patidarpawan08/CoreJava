/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.LeftFood;

import java.util.ArrayList;

/**
 *
 * @author Pawan
 */
public class LeftFoodDirectory {
    private ArrayList<LeftFood> leftFoodDirectory;

    public ArrayList<LeftFood> getLeftFoodDirectory() {
        return leftFoodDirectory;
    }

    public void setLeftFoodDirectory(ArrayList<LeftFood> leftFoodDirectory) {
        this.leftFoodDirectory = leftFoodDirectory;
    }
    
    public LeftFoodDirectory()
    {
        this.leftFoodDirectory= new ArrayList<>();
    }
    public void addLeftFood(LeftFood leftFood)
    {
        leftFoodDirectory.add(leftFood);
    }
}
