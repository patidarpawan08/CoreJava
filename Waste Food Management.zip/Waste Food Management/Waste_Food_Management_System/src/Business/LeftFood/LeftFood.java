/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.LeftFood;

import java.sql.Time;
import java.util.Date;

/**
 *
 * @author Pawan
 */
public class LeftFood  {
    
    private int quantity;
    private String pickupDate;
    private String pickupTime;
    private String distributionLocation;
    private String distributionTime;
    private int remainiingFoodAfterDist;

    public String getPickupDate() {
        return pickupDate;
    }

    public String getDistributionLocation() {
        return distributionLocation;
    }

    public int getRemainiingFoodAfterDist() {
        return remainiingFoodAfterDist;
    }

    public void setRemainiingFoodAfterDist(int remainiingFoodAfterDist) {
        this.remainiingFoodAfterDist = remainiingFoodAfterDist;
    }

    public void setDistributionLocation(String distributionLocation) {
        this.distributionLocation = distributionLocation;
    }

    public String getDistributionTime() {
        return distributionTime;
    }

    public void setDistributionTime(String distributionTime) {
        this.distributionTime = distributionTime;
    }

    public void setPickupDate(String pickupDate) {
        this.pickupDate = pickupDate;
    }

    public String getPickupTime() {
        return pickupTime;
    }

    public void setPickupTime(String pickupTime) {
        this.pickupTime = pickupTime;
    }
    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
   @Override
    public String toString()
    {
     return this.getPickupTime();
    }
    
    
    
}
