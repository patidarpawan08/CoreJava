/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Enterprise;

import Business.Role.Role;
import java.util.ArrayList;

/**
 *
 * @author Pawan
 */
public class Food_CheckingEnterprise extends Enterprise {

public Food_CheckingEnterprise(String name) {
        super(name, EnterpriseType.Food_Checking);
    }

    @Override
    public ArrayList<Role> getSupportedRole() {
        return null;
    }
    

}
