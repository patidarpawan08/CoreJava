/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Enterprise;

import Business.Network.Network;
import Business.Organization.Organization;
import Business.Organization.OrganizationDirectory;

/**
 *
 * @author Shubham
 */
public abstract class Enterprise  extends Organization{
    
    private OrganizationDirectory organizationDirectory;

    public OrganizationDirectory getOrganizationDirectory() {
        return organizationDirectory;
    }

   
    
    private  EnterpriseType enterpriseType;

    public EnterpriseType getEnterpriseType() {
        return enterpriseType;
    }

    public void setEnterpriseType(EnterpriseType enterpriseType) {
        this.enterpriseType = enterpriseType;
    }
    
     public enum EnterpriseType{
     
         Food_Source("Food_Source"),
         Food_Checking("Food_Checking");
         private String value;

        public String getValue() {
            return value;
        }
        private EnterpriseType(String value){
            this.value = value;
        }
        public void setValue(String value) {
            this.value = value;
        }
        @Override
        public String toString(){
        return value;
     }
         
     }
    public Enterprise(String name, EnterpriseType enterpriseType) {
        super(name);
        this.enterpriseType = enterpriseType;
        organizationDirectory = new OrganizationDirectory();
    }
    
    
}
