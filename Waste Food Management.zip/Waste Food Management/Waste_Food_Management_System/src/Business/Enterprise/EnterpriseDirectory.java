/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Enterprise;

import Business.Organization.Organization;
import Business.UserAccount.UserAccount;
import java.util.ArrayList;

/**
 *
 * @author Shubham
 */
public class EnterpriseDirectory {
    
    private ArrayList<Enterprise> enterpriseList;
    
    public EnterpriseDirectory(){
    enterpriseList = new ArrayList();
    
    }

    public ArrayList<Enterprise> getEnterpriseList() {
        return enterpriseList;
    }

    public void setEnterpriseList(ArrayList<Enterprise> enterpriseList) {
        this.enterpriseList = enterpriseList;
    }
     
    public Enterprise createAndAddEnterprise(String name, Enterprise.EnterpriseType enterpriseType){
        Enterprise enterprise = null;
        if(enterpriseType == Enterprise.EnterpriseType.Food_Source)
        {
        enterprise=new Food_SourceEnterprise(name);
        
        enterpriseList.add(enterprise);
        }
       else if(enterpriseType == Enterprise.EnterpriseType.Food_Checking)
        {
        enterprise=new Food_CheckingEnterprise(name);
        
        enterpriseList.add(enterprise);
        }
        
       return enterprise;
    }
    
    public boolean checkEnterprise(String name)
    {
    for(Enterprise e : enterpriseList)
    {
        if (e.getName().equalsIgnoreCase(name))
        {
            return true;
        }
    }
    return false;
    }
    
    public boolean checkEnterpriseUserName(String name) {
        for (Enterprise e : enterpriseList) {
            for (UserAccount us : e.getUserAccountDirectory().getUserAccountList()) {
                if (us.getUsername().equalsIgnoreCase(name)) {
                    return true;
                }
                for(Organization o : e.getOrganizationDirectory().getOrganizationList())
                {
                    for(UserAccount ua:o.getUserAccountDirectory().getUserAccountList())
                    {
                        if(ua.getUsername().equalsIgnoreCase(name))
                        {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }
    
    
}
