/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Driver;

import java.util.ArrayList;

/**
 *
 * @author Pawan
 */
public class DriverDirectory {
    
    private ArrayList<Driver> driverDirectory;
    
    public DriverDirectory()
    {
        this.driverDirectory= new ArrayList<Driver>();
    }

    public ArrayList<Driver> getDriverDirectory() {
        return driverDirectory;
    }

    public void setDriverDirectory(ArrayList<Driver> driverDirectory) {
        this.driverDirectory = driverDirectory;
    }
    
    public Driver addDriver()
    {
        Driver driver = new Driver();
        driverDirectory.add(driver);
        return driver;
    }
    
    public void deleteDriver(Driver driver)
    {
        driverDirectory.remove(driver);
    }
    
    
    
}
